create or replace function GET_DNAME(p_deptno number) return varchar2
is
  l_dname	dept.dname%type;
begin
  select dname into l_dname
  from dept
  where deptno=p_deptno;
  return l_dname;
exception
  when others then
     return null;
end;
/