package com.example.jdbctest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbctestApplicationTests {

	@Test
	void contextLoads() {
	}

}
