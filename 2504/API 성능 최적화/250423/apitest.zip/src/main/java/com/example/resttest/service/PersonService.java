package com.example.resttest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.example.resttest.model.Person;
import com.example.resttest.repository.PersonRespository;

@Service
public class PersonService {

	@Autowired
	private PersonRespository personRespository;


	@Cacheable("persons")
	public List<Person> getAllPersons(){
		return personRespository.findAll();
	}

	public Optional<Person>  getPersonById( Long id){
		return personRespository.findById(id);
	}

	@CacheEvict(value = "persons", allEntries = true)
	public Person savePerson( Person person) {
		return personRespository.save(person);
	}

	@CacheEvict(value = "persons", allEntries = true)
	public void deletePerson( Long id)
	{
		personRespository.deleteById(id);
	}
}
