export const options = {
    vus: 50,
    duration: '15s',
  
    thresholds: {
      'http_req_failed': ['rate<0.01'],  // 실패율 1% 미만이어야 성공
      'http_req_duration': ['p(95)<500'], // 95% 응답이 500ms 미만이어야 성공
    }
  };
  