import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  vus: 20,
  duration: '20s',
};

export default function () {
  // 로그인 요청 (POST)
  const loginRes = http.post('http://localhost:8080/api/login', JSON.stringify({
    username: 'user1',
    password: 'pass1'
  }), {
    headers: { 'Content-Type': 'application/json' },
  });

  check(loginRes, { '로그인 성공': (res) => res.status === 200 });

  const token = loginRes.json('token');  // 토큰 추출

  // 인증된 요청 (GET)
  const res = http.get('http://localhost:8080/api/protected', {
    headers: { Authorization: `Bearer ${token}` },
  });

  check(res, { '보호된 요청 응답 성공': (res) => res.status === 200 });

  sleep(1);
}
// 로그인 흐름 테스트
