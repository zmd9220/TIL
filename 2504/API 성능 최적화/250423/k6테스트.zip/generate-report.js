const reporter = require('k6-html-reporter');

const options = {
  jsonFile: 'result.json',          // 요약 데이터 파일 경로
  output: 'summary-report.html'     // 생성될 HTML 리포트 파일명
};

reporter.generateSummaryReport(options);
