import json
import pandas as pd

# 결과 파일 로드
with open('k6-results/result.json', 'r') as f:
    data = json.load(f)

# 원하는 항목 추출
metrics = data['metrics']
rows = []

for key, value in metrics.items():
    row = {
        'metric': key,
        'avg': value.get('avg'),
        'min': value.get('min'),
        'max': value.get('max'),
        'p(90)': value.get('p(90)'),
        'p(95)': value.get('p(95)'),
        'count': value.get('count')
    }
    rows.append(row)

# Excel로 저장
df = pd.DataFrame(rows)
df.to_excel('k6_result.xlsx', index=False)
