import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  stages: [
    { duration: '10s', target: 50 },   // 10초 동안 50명까지 증가
    { duration: '20s', target: 100 },  // 20초 동안 100명 유지
    { duration: '10s', target: 0 },    // 10초 동안 종료
  ],
};

export default function () {
  const res = http.get('http://localhost:8080/api/test');
  check(res, { 'status is 200': (r) => r.status === 200 });
  sleep(1);
}
//단계적 부하증가