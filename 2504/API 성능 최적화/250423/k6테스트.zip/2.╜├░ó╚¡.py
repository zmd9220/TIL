import matplotlib.pyplot as plt
import pandas as pd
plt.rcParams['font.family'] = 'Malgun Gothic'
plt.rcParams['axes.unicode_minus'] = False


# 엑셀 파일 로드
df = pd.read_excel("k6_result.xlsx")
numeric_df = df.dropna(subset=['avg', 'min', 'max'])
metrics = numeric_df['metric']
avg_values = numeric_df['avg']
min_values = numeric_df['min']
max_values = numeric_df['max']


plt.figure(figsize=(12, 6))

# 선 세 개: 평균, 최소, 최대
plt.plot(metrics, avg_values, marker='o', label='평균 응답 시간 (avg)')
plt.plot(metrics, min_values, marker='x', label='최소 응답 시간 (min)', linestyle='--')
plt.plot(metrics, max_values, marker='s', label='최대 응답 시간 (max)', linestyle=':')

plt.xticks(rotation=45, ha='right')
plt.xlabel('측정 항목 (metric)')
plt.ylabel('시간 (ms)')
plt.title('K6 부하 테스트 응답 시간 분석')
plt.legend()
plt.tight_layout()

plt.show()
