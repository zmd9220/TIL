// script.js
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  vus: 100, // 가상 유저 수
  duration: '10s', // 테스트 시간
};

export default function () {
  const res = http.get('http://localhost:8081/test');
  check(res, { 'status is 200': (r) => r.status === 200 });
  sleep(1);
}



// 1. 설치 :https://github.com/grafana/k6/releases
//k6-v1.0.0-rc1-windows-amd64.msi
// 2. 설치 후 환경변수 설정
// 환경변수 설정 후 터미널에서 k6 명령어 확인
// 터미널에서 k6 명령어 확인
// 3. k6 --version
// 4. k6 run script.js
// 4. k6 run --summary-export=result.json script.js
// 5. k6 run script.js --out json=result.json
// 6. npm install k6-html-reporter --save-dev
// 7. node generate-report.js




// 위 테스트는 스레드 풀이 얼마나 효율적으로 요청을 처리하는지 확인하는 데 도움.
// 설정에 따라 200개는 바로 처리, 나머지는 accept-count 만큼 대기, 초과 시 503 응답 가능
// 정상 처리된 요청: 200 OK
// 서버가 못 받는 요청: 503 Service Unavailable
// 대기 큐에서 처리 지연됨: 응답 시간 증가 확인 가능