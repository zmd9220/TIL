package com.example.jdbctest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbctestApplication {

	public static void main(String[] args) {
		SpringApplication.run(JdbctestApplication.class, args);
	}

}
