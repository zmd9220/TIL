package com.example.jdbctest.my;

import org.springframework.stereotype.Component;

@Component
public class MyClass {

	public String hello() {
		return "hello myclass";
	}
}
