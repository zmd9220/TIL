package com.example.obesity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObesityApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObesityApplication.class, args);
	}

}
