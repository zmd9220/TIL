package com.example.obesity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObesityApplicationTests {

	@Test
	void contextLoads() {
	}

}
