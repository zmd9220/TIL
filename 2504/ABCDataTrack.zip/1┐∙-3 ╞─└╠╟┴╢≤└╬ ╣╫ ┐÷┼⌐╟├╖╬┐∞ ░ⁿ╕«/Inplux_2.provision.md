# InfluxDB Provisioning
## 설치
1. 공식 저장소 추가
```
wget -qO- https://repos.influxdata.com/influxdb.key | sudo apt-key add -
echo "deb https://repos.influxdata.com/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/influxdb.list
```
2. InfluxDB 설치
```
sudo apt-get update && sudo apt-get install influxdb
```
3. InfluxDB 서비스 시작
```
sudo systemctl start influxdb
```
4. 서비스 상태 확인
```
sudo systemctl status influxdb
```
5. 서비스 자동 시작 설정
```
sudo systemctl enable influxdb
```
## Docker 실행
* General
```
docker pull influxdb
docker run --name influxdb -p 8086:8086 -d influxdb
docker exec -it influxdb influx
```
* Specfic Version
```
docker rm -f test-influxdb-client
docker run -it  --rm                                                   \
 --network test-net                                                    \
 --name test-influxdb-client                                           \
  influxdb:1.8.10 /usr/bin/influx -host 172.18.0.3  -password lotte1 -username lotte1 -database lotte1
```
