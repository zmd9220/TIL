# InfluxDB 정보
## 정의
* == InfluxDB는 시계열 데이터를 효율적으로 관리할 수 있는 강력한 도구
* 오픈 소스 데이터베이스
## 설명
* 시계열 데이터는 시간의 흐름에 따라 측정되거나 기록된 데이터로, 주식 시장 데이터, IoT 장치에서 수집한 데이터, 애플리케이션 성능 모니터링 데이터 등 다양한 형태가 있음. 
* 시계열 데이터를 빠르고 효율적으로 처리할 수 있도록 최적화되어 있음.  
* 사용하기 쉬운 쿼리 언어, 높은 가용성, 데이터 복제 기능을 제공
## 특징
* 고성능: 메모리와 CPU 사용 최적화로 빠른 데이터 쓰기 및 쿼리 속도 제공
* 쉬운 데이터 쓰기 및 쿼리: InfluxQL 및 Flux를 포함한 강력한 쿼리 언어 지원
* 데이터 보존 정책: 자동 데이터 만료 및 롤링으로 디스크 공간 효율적 관리
* 확장성: 클러스터링을 통한 수평적 확장 지원
## 링크
* 홈페이지: [InfluxDB 공식 홈페이지](https://www.influxdata.com/)
* 매뉴얼: [InfluxDB 문서](https://docs.influxdata.com/influxdb/)
* 커뮤니티: [InfluxData 커뮤니티](https://community.influxdata.com/)
* GitHub: [InfluxDB GitHub](https://github.com/influxdata/influxdb)

# Admin
## 초기 설정
```
orgNme=lotte1

influx setup \
--username prj1 \
--password lotte1prj1 \
--org $orgName \
--bucket prj1 \
--retention 365d \
--force
export INFLUX_TOKEN=$(influx auth list|grep Token|grep ==|awk '{print $4}')
[[ ! $INFLUX_TOKEN ]]&&echo "export INFLUX_TOKEN=$INFLUX_TOKEN" > ~/.bashrc &&  .~/.bashrc
[[ ! $orgName ]]&&echo "export orgName=lotte1"                   > ~/.bashrc && . ~/.bashrc
. ~/.bashrc
echo $INFLUX_TOKEN >  /var/lib/influxdb2/token
```
## 데이터 제거
InfluxDB 2에서 모든 데이터를 클리어하는 방법은 크게 두 가지가 있음. 데이터 삭제는 데이터 구조와 데이터 크기에 따라 다르게 접근해야 함.

### 1. 모든 데이터베이스 삭제
데이터베이스를 삭제하면 해당 데이터베이스에 있는 모든 데이터가 삭제됨.

```bash
influx bucket delete --name <bucket_name>
```

### 2. 시리즈 데이터 삭제
특정 시리즈 또는 측정값에 대한 데이터를 삭제할 수 있음.

```bash
influx delete \
  --bucket <bucket_name> \
  --start 1970-01-01T00:00:00Z \
  --stop $(date +%Y-%m-%dT%H:%M:%SZ) \
  --predicate '_measurement="<measurement_name>"'
```

이 명령은 주어진 시간 범위 내에서 특정 측정값의 모든 데이터를 삭제함.

### 3. 스크립트를 이용한 모든 데이터 삭제
모든 데이터를 삭제하기 위해 스크립트를 사용할 수 있음.

```bash
#!/bin/bash
export orgName=lotte1
BUCKET_NAME="prj1"
START="1970-01-01T00:00:00Z"
STOP=$(date +%Y-%m-%dT%H:%M:%SZ)

influx delete --bucket $BUCKET_NAME --start $START --stop $STOP --org "$orgName"
influx query 'from(bucket: "prj1") |> range(start: -1h)' --org $orgName
```

이 스크립트를 실행하면 해당 버킷의 모든 데이터가 삭제됨.

### 참고 사항
- 데이터 삭제는 복구가 불가능하므로 신중하게 수행해야 함.
- InfluxDB의 버전에 따라 명령어가 다를 수 있으므로, 사용 중인 버전에 맞는 명령어를 확인해야 함.


# InfluxDB Command
```

[[ ! $INFLUX_TOKEN ]]&& export INFLUX_TOKEN=$(cat /var/lib/influxdb2/token)
[[ ! $orgName ]]&&export orgName=lotte1
influx auth list --host http://localhost:8086
influx write -b prj1 -o "$orgName" -p s "measurement,host=host1 field1=1,field2=2"
influx query 'from(bucket: "prj1") |> range(start: -1h)'  --org "$orgName"

```

* auth list
```
influx auth list --host http://localhost:8086 
```

* orgName List
```
influx org list 
```
# Client Programming
## Python Client
```
from influxdb_client import InfluxDBClient
from influxdb_client.client.write_api import SYNCHRONOUS

# InfluxDB 서버 정보 설정
url = "http://ts:8086"  # 호스트명과 포트
token = "yN2HFNQ8pPC_6Ix7ysny75o6HXW8KuMPVWR5MvfjC6pFk93TLT-qsWBEcTgpXebmignu3hY0KMV9uWMechYEwA=="  # InfluxDB 토큰 (보안 이유로 환경변수로 관리 추천)
org = "lotte1"  # 조직명
bucket = "prj1"  # 버킷명

# 클라이언트 생성
client = InfluxDBClient(url=url, token=token, org=org)

# 쿼리 실행
query = 'from(bucket: "prj1") |> range(start: -1h)'
tables = client.query_api().query(query, org=org)

# 결과 출력
for table in tables:
    for record in table.records:
        print(record.get_time())
        print(f'Time: {record.get_time()}, Host: {record.values["host"]}, field_name: {record.get_field()} , value: {record.get_value()}')

# 클라이언트 종료
client.close()

```
# influxDB 정리할

```bash
# InfluxDB 설정
influx setup \
--username prj1 \              # 사용자 이름 설정
--password lotte1prj1 \         # 사용자 비밀번호 설정
--org lotte1 \                  # 조직 이름 설정
--bucket prj1 \                # 버킷 이름 설정
--retention 365d               # 데이터 보존 기간 설정 (365일)

# 인증 토큰 목록 조회
influx auth list

# 버킷 목록 조회
influx bucket list

# 새로운 버킷 생성
influx bucket create \
--name prj12 \                 # 새로운 버킷 이름 설정
--org lotte1 \                  # 조직 이름 설정
--retention 365d               # 데이터 보존 기간 설정 (365일)
influx bucket list             # 버킷 목록 조회 (새로운 버킷 확인)

# 데이터 쓰기
influx write -b prj1 -o lotte1 -p s "measurement,host=host1 field1=1,field2=2"
                                # 'prj1' 버킷에 데이터 쓰기
                                # -b: 버킷 이름, -o: 조직 이름, -p: 포맷
                                # 데이터 포맷: measurement, 태그: host=host1, 필드: field1=1, field2=2

# 데이터 쿼리 (최근 1시간 범위)
influx query 'from(bucket: "prj1") |> range(start: -1h) |> filter(fn: (r) => r._measurement == "measurement")' --org lotte1
                                # 'prj1' 버킷에서 최근 1시간 동안의 'measurement' 측정 데이터 필터링하여 쿼리

# 데이터 삭제
influx delete --bucket prj1 --start $START --stop $STOP --org lotte1
                                # 'prj1' 버킷에서 $START부터 $STOP까지의 데이터 삭제
                                # -bucket: 버킷 이름, --start: 시작 시간, --stop: 종료 시간, --org: 조직 이름

# 데이터 쿼리 (최근 1시간 범위)
influx query 'from(bucket: "prj1") |> range(start: -1h)' --org lotte1
                                # 'prj1' 버킷에서 최근 1시간 동안의 모든 데이터 쿼리

```