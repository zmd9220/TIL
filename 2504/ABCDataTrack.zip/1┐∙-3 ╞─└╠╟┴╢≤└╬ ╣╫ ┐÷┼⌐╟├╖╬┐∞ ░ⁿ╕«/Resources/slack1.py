from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import slack_sdk

def slack_alert():
    slack_token = 'xoxp-8253741173655-8268185651539-8267290295686-3f6b0f642667784e6886db13579275ab'
    client = slack_sdk.WebClient(token=slack_token)
    response = client.chat_postMessage(
        channel="channel1",  
        text=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )

# DAG 정의
with DAG(
    'slack1',  # DAG ID
    start_date=datetime(2024, 1, 10),  # 시작 날짜
    schedule_interval='0 * * * *',  # 스케줄: 매 시간
    catchup=False  # 시작 날짜 이전의 실행 건 무시
) as dag:
    slack_alert = PythonOperator(
        task_id='slack_alert',
        python_callable=slack_alert
    )

    # Task 의존성 설정
    slack_alert