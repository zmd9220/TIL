# Python TDD (Test-Driven Development)

## TDD란?

Test-Driven Development(TDD)는 소프트웨어 개발 방법론으로, 코드를 작성하기 전에 테스트를 먼저 작성하는 방식임.
테스트를 기반으로 기능을 구현하고 점진적으로 개선하는 반복적 프로세스를 통해 높은 품질의 코드를 보장함.

---

## TDD의 주요 단계

1. **테스트 작성**

   - 작성하려는 기능에 대한 테스트를 먼저 작성.
   - 테스트는 실패하는 상태여야 함 (Failing Test).
   - ex) 입력값과 기대 출력값 정의.

2. **코드 작성**

   - 테스트를 통과하기 위한 최소한의 코드를 작성.
   - 복잡도를 최소화하고, 기능 중심으로 구현.

3. **리팩토링**

   - 코드 및 테스트를 정리하고 최적화.
   - 중복 제거, 성능 개선, 가독성 향상 등 수행.
   - 테스트가 여전히 통과하는지 확인.

---

## Python에서 TDD를 구현하는 방법

### 1. 테스트 프레임워크 선택

Python의 주요 테스트 프레임워크:

- **unittest**: Python 표준 라이브러리.
- **pytest**: 간결한 문법과 강력한 확장성을 제공.
- **nose2**: unittest 기반의 확장 프레임워크.

### 2. 기본적인 테스트 구조

pytest를 활용하여 간단하고 직관적인 테스트 작성 가능:

```python
# 파일: test_script.py
import pytest
import pandas as pd

def test_age_range():
    data = pd.DataFrame({'age': [25, 45, 130, -5]})
    invalid_values = data[(data['age'] < 0) | (data['age'] > 120)]
    assert invalid_values.empty, f"유효하지 않은 값: {invalid_values}"

if __name__ == "__main__":
    test_age_range()
```

### 3. 객체지향 프로그래밍(OOP) 코드 검증 예제

TDD를 사용해 OOP 코드의 동작을 검증하는 예제:

```python
# 파일: test_oop.py
import pytest

class Calculator:
    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b

def test_calculator():
    calc = Calculator()

    # 덧셈 테스트
    assert calc.add(2, 3) == 5, "Addition test failed"

    # 뺄셈 테스트
    assert calc.subtract(5, 3) == 2, "Subtraction test failed"

if __name__ == "__main__":
    pytest.main()
```

pytest는 test_calculator 함수를 자동으로 실행한다.
### 4. 테스트 실행

터미널에서 다음 명령어로 실행:

```bash
pytest -q test_script.py   # 단일 테스트 파일 실행
pytest -q test_oop.py      # OOP 테스트 실행
pytest --maxfail=2         # 실패한 테스트 2개에서 실행 중단
pytest --disable-warnings  # 경고 메시지 비활성화
```

#### 주요 옵션 설명

| 옵션                 | 설명                                |
|----------------------|-----------------------------------|
| `-q`                | 간결한 출력 모드                       |
| `--maxfail=N`        | N개 테스트 실패 시 실행 중단             |
| `--disable-warnings` | 경고 메시지를 출력하지 않음              |
| `-k <expression>`    | 특정 이름의 테스트만 실행               |
| `--capture=no`       | 테스트 출력 캡처 비활성화               |
| `--tb=short`         | 간단한 traceback 출력 형식 사용          |

---

## TDD의 장점

- **품질 향상**: 코드의 결함을 사전에 방지.
- **유지보수 용이**: 테스트가 리팩토링 시 코드 안정성을 보장.
- **문서 대체**: 테스트 코드 자체가 동작 방식의 문서 역할 수행.
- **빠른 피드백 루프**: 코드를 바로 검증 가능.

## TDD의 단점

- **초기 비용**: 테스트 작성 시간이 추가로 소요.
- **학습 곡선**: 초기에 TDD 방식을 익히는 데 시간 필요.
- **불필요한 테스트**: 잘못된 설계로 불필요한 테스트를 작성할 위험.

---

## TDD Best Practices

1. **작은 단위로 테스트**: 하나의 테스트는 하나의 기능만 검증.
2. **자주 실행**: 테스트를 자주 실행해 피드백을 빠르게 받음.
3. **명확한 네이밍**: 테스트 이름에 기능 및 조건을 명확히 포함.
4. **테스트 독립성 보장**: 각 테스트는 다른 테스트에 의존하지 않아야 함.
5. **커버리지 확인**: 코드 커버리지를 분석해 테스트 누락 방지.

---

## 참고 자료

1. **Python 공식 문서**: https://docs.python.org/3/library/unittest.html
2. **pytest 공식 문서**: https://docs.pytest.org/en/stable/
3. **Test-Driven Development By Example** - Kent Beck
4. **Effective Python Testing with Pytest** - Brian Okken

---

## 마무리

TDD는 코드를 설계하고 구현하는 과정에서 품질을 높이는 강력한 도구임.
Python의 다양한 테스트 프레임워크를 활용해 실습을 반복하면, TDD를 효과적으로 적용 가능.

