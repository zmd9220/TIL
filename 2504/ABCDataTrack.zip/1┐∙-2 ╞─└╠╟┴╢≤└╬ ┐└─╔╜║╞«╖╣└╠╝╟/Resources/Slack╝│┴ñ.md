# 1. 환경 설정
```
docker run -it --name u1 --rm -p 8081:8080 -v ${HOME}/df2:/df ubuntu

apt update && apt install -y python3 python3-pip python3-venv vim
pip install --break-system-packages apache-airflow tmux
pip install --break-system-packages apache-airflow-providers-slack
#pip install --break-system-packages slackclient


airflow db init

mkdir /df/dags
sed -i 's|^\(dags_folder\s*=\s*\).*|\1/df/dags|' /root/airflow/airflow.cfg
cat /root/airflow/airflow.cfg |grep dags_folder

tmux kill-session -t airflow_web
tmux kill-session -t airflow_sch
tmux new-session -d -s airflow_web 'airflow webserver -p 8080'
tmux new-session -d -s airflow_sch 'airflow scheduler'
tmux ls 

airflow users create \
--username admin \
--password admin \
--firstname Admin \
--lastname User \
--role Admin \
--email admin@example.com

cat <<EOF> /df/dags/simple_dag.py
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
def do():
    print("do")
with DAG(
    'simple_dag',
    start_date=datetime(2023, 1, 1),
    schedule_interval='@daily',
    catchup=False
) as dag:
    do_it = PythonOperator(
        task_id='doit',
        python_callable=do
    )
    do_it
EOF

sleep 3
airflow dags list |grep simple
```

# 2. Token 설정

* https://app.slack.com → "Create Workspace" → `Check All option` & Create a Workspace  → What’s the name of your company or team? == airflow1 → Next  → Skip this step → "alerttest"(체널명) → Start with Free

* https://api.slack.com/apps → "Create New App" → "From scratch" → AppName:airflow1,Pick a workspace to develop your app in: airflow1 → OAuth&Permissions → User Token Scopes의 "Add an OAuth Scope"클릭 → chat:write 검색해서 선택 → OAuth Tokens에서 "Install to airflow1"버튼 클릭 → Allow클릭 → (자동으로 원복됨) → User OAuth Token의 Copy버튼 클릭해서 토큰 메모장에 갈무리

pip install slack-sdk

* python3 콘솔에서 아래 코드의 slack_token 설정(위 복사한 OAuth Token) 후 붙여넣기.
```
import slack_sdk
slack_token = 'xoxp-XXXXXXXX'
client = slack_sdk.WebClient(token=slack_token)
slack_msg = "hi1"
response = client.chat_postMessage(
    channel="alerttest",  
    text=slack_msg
)
print(response)  # 응답 확인용
```

* Slack에서 메세지 전송 확인!!

# 2. Airflow Connection 활용  추가 연습
* 출처 : https://devops-space.tistory.com/33 (가영님 제공)
* https//localhost:8081 → Admin Menu → Connections → Add a new record ( + 버튼 ) → Connection Id: slack_api_default → Connection Type: Slack API → Slack API Token에 메모장에 갈무리해 둔 OAuth Tokens 복붙 → Save
 
* 아래 코드 실행 
```
cat <<EOF> /df/dags/slack_fail_alert.py
from airflow.hooks.base_hook import BaseHook
from airflow.operators.slack_operator import SlackAPIPostOperator

class SlackAlert:
    def __init__(self, channel):
        self.slack_channel = channel
        self.slack_token = BaseHook.get_connection('slack_api_default').password

    def slack_fail_alert(self, context):
        alert = SlackAPIPostOperator(
            task_id='slack_failed',
            channel=self.slack_channel,
            text="""
                :red_circle: Task Failed.
                *Task*: {task}  
                *Dag*: {dag}
                *Execution Time*: {exec_date}  
                *Log Url*: {log_url}
                """.format(
                    task=context.get('task_instance').task_id,
                    dag=context.get('task_instance').dag_id,
                    exec_date=context.get('execution_date'),
                    log_url=context.get('task_instance').log_url
                    )
                  )
        return alert.execute(context=context)
EOF

cat <<EOF> /df/dags/Slack_test.py
from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

from airflow.providers.slack.operators.slack import SlackAPIPostOperator
from airflow.providers.slack.notifications.slack import send_slack_notification

from slack_fail_alert import SlackAlert

# DAG 기본 설정
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 5),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'on_success_callback': [
            send_slack_notification(
                text="The DAG {{ dag.dag_id }} succeeded",
                channel="#alerttest"
            )
        ],
}

# DAG 정의
dag = DAG(
    'Slack_test',
    default_args=default_args,
    description='A simple tutorial DAG',
    schedule_interval=timedelta(days=1),
)

# 첫 번째 Bash 작업
task1 = BashOperator(
    task_id='print_date',
    bash_command='date',
    dag=dag,
)

# 세 번째 Bash 작업
task2 = BashOperator(
    task_id='print_hello',
    bash_command='echo "Hello World"',
    dag=dag,
)

slack_alert = SlackAPIPostOperator(
    task_id="slack_alert",
    channel='#alerttest',
    blocks=[
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": (
                    "*<https://github.com/apache/airflow|Apache Airflow™>* "
                    "is an open-source platform for developing, scheduling, "
                    "and monitoring batch-oriented workflows."
                ),
            }
        }
    ],
    text="Fallback message",
)
# 작업 순서 정의
task1 >> task2 >> slack_alert
EOF

* u1의 터미널에서 Dag생성 여부 확인
```
airflow dags list |grep Slack
```

* 브라우저에서 localhost:8081 접속후 DAGs에서 "Slack_test" 검색후 "Toggle DAG"(play버튼) 클릭 후 Slack Message확인 

